package com.example.demo.service;

public interface logonService {
    // 获得账号密码、登录状态，若登陆成功，反馈成功，并为下一页面准备页面课程信息{课程图片、课程name、课程teacher}，若失败，进入失败反馈
    //成功返回用户和用户的课程具体基础信息

}
