package com.example.demo.service;

import com.example.demo.entity.Teacherrelclass;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author 作者
 * @since 2022-03-28
 */
public interface TeacherrelclassService extends IService<Teacherrelclass> {

}
