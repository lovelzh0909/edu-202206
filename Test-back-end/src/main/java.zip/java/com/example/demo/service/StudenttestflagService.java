package com.example.demo.service;

import com.example.demo.entity.Studenttestflag;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author 作者
 * @since 2022-04-08
 */
public interface StudenttestflagService extends IService<Studenttestflag> {

}
