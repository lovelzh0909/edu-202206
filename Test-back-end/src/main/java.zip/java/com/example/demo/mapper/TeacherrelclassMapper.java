package com.example.demo.mapper;

import com.example.demo.entity.Teacherrelclass;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author 作者
 * @since 2022-03-28
 */
@Mapper
public interface TeacherrelclassMapper extends BaseMapper<Teacherrelclass> {

}
