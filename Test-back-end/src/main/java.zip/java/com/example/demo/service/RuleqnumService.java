package com.example.demo.service;

import com.example.demo.entity.Ruleqnum;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author 作者
 * @since 2022-03-25
 */
public interface RuleqnumService extends IService<Ruleqnum> {

}
