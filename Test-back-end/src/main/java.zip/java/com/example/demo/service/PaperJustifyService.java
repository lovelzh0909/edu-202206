package com.example.demo.service;

import com.example.demo.entity.PaperJustify;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 用于存储学生问题答案	 服务类
 * </p>
 *
 * @author 作者
 * @since 2022-03-17
 */
public interface PaperJustifyService extends IService<PaperJustify> {

}
